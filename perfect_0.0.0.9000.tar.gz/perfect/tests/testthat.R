library(testthat)
library(perfect)

test_check("perfect")
